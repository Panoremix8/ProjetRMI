package jeumorpion;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface MorpionInterface extends Remote {
	
	public String checkWinner (String[] board, String turn) throws RemoteException;
	
	public void printBoard(String[] board) throws RemoteException;

}

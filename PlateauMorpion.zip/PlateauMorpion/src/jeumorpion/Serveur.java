package jeumorpion;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;

public class Serveur {
	public static void main(String[] argv) {
		try {
			int port = 8000;
			LocateRegistry.createRegistry(port);
			Naming.rebind("rmi://localhost:" + port + "/morpion", new MorpionImpl());
			System.out.println("Server pret !");
		}
		catch (Exception e) {
			System.out.println("Server echec " + e);
		}
	}
}

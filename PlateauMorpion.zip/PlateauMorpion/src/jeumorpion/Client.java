package jeumorpion;
import java.rmi.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Client {
	public static void  main(String[] argv) {
		try {
			int port = 8000;
			MorpionInterface obj = (MorpionInterface) Naming.lookup("rmi://localhost:" + port + "/morpion");
			
			String[] board;
		    String turn;
			
			Scanner in = new Scanner(System.in);
	        board = new String[9];
	        turn = "X";
	        String winner = null;

	  
	        for (int a = 0; a < 9; a++) {
	            board[a] = String.valueOf(a + 1);
	        }
	  
	        System.out.println("Bienvenue dans le jeu du Morpion !");
	        obj.printBoard(board);
	        System.out.println("---------------------------------------");
	  
	        System.out.println(
	            "X joue en premier. Entrez une place afin de placer X :");
	  
	        while (winner == null) {
	            int numInput;
	            

	            try {
	                numInput = in.nextInt();
	                if (!(numInput > 0 && numInput <= 9)) {
	                    System.out.println(
	                        "Erreur, essayez une autre place :");
	                    continue;
	                }
	            }
	            catch (InputMismatchException e) {
	                System.out.println(
	                    "Erreur, essayez une autre place :");
	                continue;
	            }

	            if (board[numInput - 1].equals(
	                    String.valueOf(numInput))) {
	                board[numInput - 1] = turn;
	  
	                if (turn.equals("X")) {
	                    turn = "O";
	                }
	                else {
	                    turn = "X";
	                }
	  
	                obj.printBoard(board);
	                System.out.println("|---|---|---|");
	    	        System.out.println("| " + board[0] + " | "+ board[1] + " | " + board[2] + " |");
	    	        System.out.println("|-----------|");
	    	        System.out.println("| " + board[3] + " | "+ board[4] + " | " + board[5]+ " |");
	    	        System.out.println("|-----------|");
	    	        System.out.println("| " + board[6] + " | "+ board[7] + " | " + board[8] + " |");
	    	        System.out.println("|---|---|---|");
	                winner = obj.checkWinner(board, turn);
	            }
	            else {
	                System.out.println(
	                    "Place déjà prise! essayez une autre place :");
	            }
	        }
	        
	        

	        if (winner.equalsIgnoreCase("draw")) {
	            System.out.println(
	                "Egalité! merci d'avoir joué.");
	        }
	        
	        else {
	            System.out.println(
	                "Bravo! " + winner
	                + "a gagné la partie");
	        }
		}
		catch (Exception e) {
			System.out.println("Client exception: " + e);
		}
	}
}

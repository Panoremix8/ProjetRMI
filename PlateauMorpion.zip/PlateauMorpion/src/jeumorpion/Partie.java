package jeumorpion;

import java.util.Scanner;

public class Partie {
	Plateau plateau;
	//IA ia;
	
	public Partie(int taillePlateau) {
		plateau = new Plateau(taillePlateau);
		//ia = new IA(taillePlateau);
	}
	
	public void jouer() {
		boolean joueur1Gagne = false;
		boolean joueur2Gagne = false;
		boolean egalite = false;
		int col, row;
		int tour = 2;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		
		do {
			System.out.println(plateau);
			System.out.println("Choisissez une case.");
			System.out.println("Ligne (de 1 à 3) :");
			row = scanner.nextInt() - 1;
			System.out.println("Colonne (de 1 à 3) :");
			col = scanner.nextInt() - 1;
			if (plateau.jouer(row, col, tour)) {
				if (plateau.victoire('X', tour)) {
					joueur1Gagne = true;
					System.out.println(plateau);
					System.out.println("Fin de partie.");
				} 
					if (plateau.victoire('O', tour)) {
						joueur2Gagne = true;
						System.out.println(plateau);
						System.out.println("Fin de partie.");
					}
				
			}
			if (plateau.fin() && joueur1Gagne == false && joueur2Gagne == false) {
				egalite = true;
				System.out.println(plateau);
				System.out.println("Fin de partie. Egalité.");
			}
			tour = tour + 1;
		} while (joueur1Gagne == false && joueur2Gagne == false && egalite == false);
	}
	
	
}
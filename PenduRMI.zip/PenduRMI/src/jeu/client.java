package jeu;

import java.rmi.*;

public class client {
	public static void  main(String[] argv) {
		try {
			int port = 8000;
			penduInterface obj= (penduInterface) Naming.lookup("rmi://localhost:" + port + "/pedu");
			
			
			penduImpl obj1 = new penduImpl();
			
			double nbAlea = obj1.genererAleat();
			String mot = obj1.lireMot(nbAlea);
			int nbCarac = obj1.nbCaracMot(mot);
			
			
			System.out.println("Le jeuu duuu ..... PEEENNDDUUUUUUUUUUUU\n");
			
			System.out.println("Voici me mot a deviner : " );
			obj1.afficherMotCache(obj1.Mot_vide(nbAlea, mot), nbCarac); 
			
			
			System.out.println("\n");
			
			
			obj1.tour(mot,obj1.Mot_vide(nbAlea,mot) );
			
		}
		catch (Exception e) {
			System.out.println("Client exception: " + e);
		}
	}
}
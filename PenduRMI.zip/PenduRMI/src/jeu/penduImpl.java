package jeu;
import java.io.BufferedReader;
//import java.io.File;
import java.io.FileNotFoundException;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.*;
import java.rmi.server.*;
import java.util.Scanner;

@SuppressWarnings("serial")
public class penduImpl extends UnicastRemoteObject implements penduInterface{
	
	public penduImpl() throws RemoteException{
		super();
	}
	
	public double genererAleat() throws RemoteException{
		double val;
		val = (int) (Math.random() * ( 19 - 1));
		
		return val;
	}
	
	
	public boolean verifFin(String motCache, String objectif, int erreur) {
		boolean verif = false;
		if(motCache.equals(objectif)){
			verif = true;
			System.out.println("F�licitation ! Vous avez trouv� le mot ! Pout trouver " +objectif+ " vous avez fais seulement " +erreur + " erreurs ! Impressionnant !" );
		}
		if(erreur == 10) {
			System.out.println("Dommage ! Vous avez echou� ! Le mot �tait : " +objectif);
		}
	
	return verif;
	}
	
	
	
	
	public int nbCaracMot (String objectif) {
		
		int nbCarac = objectif.length();
		return nbCarac;
	}
	
	
	public String lireMot (double val) throws IOException { 
		
		String objectif = null;
		   String fileName = "src/jeu/dictionnaire.txt";
		   int counter = 0;

		    //This will reference one line at a time
		    String line = null;
		    FileReader fileReader = null;

		    try {
		        //FileReader reads text files in the default encoding.
		        fileReader = 
		            new FileReader(fileName);

		        //Always wrap FileReader in BufferedReader.
		        BufferedReader bufferedReader = new BufferedReader(fileReader);
		        
		        while((line = bufferedReader.readLine()) != null) {
		            counter++;
		            if(counter == val)
		            {
		        		//System.out.println(line);
		        		objectif = line;
		            }
		        }   
 			
		    }
		    catch(FileNotFoundException ex) {
		        System.out.println(
		            "Unable to open file '" + 
		            fileName + "'");                
		    }
		    catch(IOException ex) {
		        System.out.println(
		            "Error reading file '" 
		            + fileName + "'");                  
		        //Or we could just do this: 
		        //ex.printStackTrace();
		    }
		    finally
		    {
		        if(fileReader != null){
		           //Always close files.
		          // bufferedReader.close();            
		        }
		    }
			return objectif;
	
	}
		
	
	
	
	
	public char[] Mot_vide (double val, String objectif) throws IOException { 
		
		   String fileName = "src/jeu/dictionnaire.txt";
		   int counter = 0;
		   int nbCarac = objectif.length();
		   char[]  word = new char[nbCarac] ;

		    //This will reference one line at a time
		    String line = null;
		    FileReader fileReader = null;

		    
		    try {
		        //FileReader reads text files in the default encoding.
		        fileReader = 
		            new FileReader(fileName);

		        //Always wrap FileReader in BufferedReader.
		        BufferedReader bufferedReader = new BufferedReader(fileReader);
		        
		      while((line = bufferedReader.readLine()) != null) {
		            counter++;
		            if(counter == val)
		            {
		            	
		        		//System.out.println(line);
		        		int u= line.length();
		        		//System.out.println(u);
		        		for(int i=0; i < u; i++) {
		        			
		        			word[i] = '-';
		        			
		        		}
		        		
		            }
		      }   
		        fileReader.close();
		        bufferedReader.close();
		    }
		    catch(FileNotFoundException ex) {
		        System.out.println(
		            "Unable to open file '" + 
		            fileName + "'");                
		    }
		    catch(IOException ex) {
		        System.out.println(
		            "Error reading file '" 
		            + fileName + "'");                  
		        //Or we could just do this: 
		        //ex.printStackTrace();
		    }
		    finally
		    {
		        if(fileReader != null){
		           //Always close files.
		          // bufferedReader.close();            
		        }
		    }
		   // System.out.println(Arrays.toString(word));
			return word;
	
	}

	
	
	
	public String afficherMotCache (char[] word, int nbCarac) {
		String motCache = "";
		for(int i = 0; i< nbCarac;i++) {
			String caracI = Character.toString(word[i]);
 			motCache = motCache.concat(caracI);
		}
		System.out.println(motCache);
		return motCache;
	}

	
	
	
	public  int tour (String objectif, char[] word) throws RemoteException {
		
		int longueur = objectif.length();
		char lettre;
		int erreur = 0;
		int i = 10;
		boolean verif = false;
		String propal = "";
		while( erreur<i ^ verif == true ) {
			
			boolean estPresent = false;
			System.out.println("Veuillez proposer une lettre :");
			Scanner sc = new Scanner(System.in);
			lettre = sc.next().charAt(0);
		 
		 
		 
			for(int o = 0; o<longueur; o++ ) {
			// System.out.println(i);
			 //System.out.println(objectif);
			// System.out.println(objectif.charAt(i));
			// System.out.println(word[i]);
			 if( objectif.charAt(o) == lettre){
				 word[o] = lettre;
				 estPresent = true;
				 //System.out.println(word[i]);
			 	}
			 
			}
			if(estPresent == false) {
				erreur++;
				System.out.println("Cette lettre n'est pas dans le mot");
			};
			affichage_pendu(erreur);
			propal = afficherMotCache(word, longueur);
			verif = verifFin(propal, objectif, erreur);
			
			
		}
		return erreur;
				
		
	}
	//affiche le pendu en fonction de son nombre d'erreurs
	public void affichage_pendu(int erreur) {
		switch (erreur){//un etat d affichage par nombre d erreur du joueur
        case 0 : System.out.println("\n\n\n\n\n\n\n"); break;
        case 1 : System.out.println("\n\n\n\n\n\n\n|\\______"); break;
        case 2 : System.out.println("\n|\n|\n|\n|\n|\n|\n|\\______"); break;
        case 3 : System.out.println("______\n|\n|\n|\n|\n|\n|\n|\\______"); break;
        case 4 : System.out.println("______\n|    |\n|\n|\n|\n|\n|\n|\\______"); break;
        case 5 : System.out.println("______\n|/   |\n|\n|\n|\n|\n|\n|\\______"); break;
        case 6 : System.out.println("______\n|/   |\n|    0\n|\n|\n|\n|\n|\\______"); break;
        case 7 : System.out.println("______\n|/   |\n|    0\n|    I\n|\n|\n|\n|\\______"); break;
        case 8 : System.out.println("______\n|/   |\n|    0\n|    I\n|   /\n|\n|\n|\\______"); break;
        case 9 : System.out.println("______\n|/   |\n|    0\n|    I\n|   / \\\n|\n|\n|\\______"); break;
        case 10 : System.out.println("______\n|/   |\n|   _0_\n|    I\n|   / \\\n|\n|\n|\\______"); break;
        default : System.out.println("erreur affichage pendu\n"); break;
    }
	}

}
	



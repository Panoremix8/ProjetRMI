package jeu;
import java.io.IOException;
import java.rmi.*;

public interface penduInterface extends Remote{
	
	public double genererAleat() throws RemoteException;//renvoie le nombre total d allumettes
	
	public String lireMot (double val) throws IOException;
	
	public boolean verifFin(String motCache, String objectif, int erreur) throws RemoteException;

	//public String tour (String motCache, int nbCarac);

	public char[] Mot_vide (double val, String objectif) throws IOException;

	public String afficherMotCache (char[] word, int nbCarac) throws RemoteException;
	
	//public char[] motTab (double val, String objectif) throws IOException;
	
}

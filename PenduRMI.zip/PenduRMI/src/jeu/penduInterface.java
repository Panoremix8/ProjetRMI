package jeu;
import java.io.IOException;
import java.rmi.*;

public interface penduInterface extends Remote{
	
	public double genererAleat() throws RemoteException;//G�n�re et retourne un nombre al�atoire entre 1 et 19
	
	public String lireMot (double val) throws IOException;//lit dans le fichier dictionnaire, et grace au nombre al�atoire, retourne la ligne du fichier correspondant et donc le mot dans un String
	
	public boolean verifFin(String motCache, String objectif, int erreur) throws RemoteException; //V�rifie la condition de victoire et de d�faite, soit le joueur fait 10 erreurs, soit le joueur trouve le mot

	public int tour ( String objectif, char[] word) throws RemoteException;//m�thode principale. a partir du tableau de tiret et du mot recherch� retourne un entier correspondant au nombre d'erreur du joueur.
	//A partir du  caractere entr� par le joueur, la m�thode va comparer chacun des caracteres du mot rechercher avec ce caractere et si il ya correspondance, l'entier sera ins�r� dans le tableau de tiret a son rang.

	public char[] Mot_vide (double val, String objectif) throws IOException;//lit dans le fichier dictionnaire, et grace au nombre al�atoire, retourne la ligne du fichier correspondant dans un tableau compos� de tirets

	public String afficherMotCache (char[] word, int nbCarac) throws RemoteException;// converti le tableau de tirets en un string et l'affiche
	
	public int nbCaracMot (String objectif) throws IOException; //retourne un entier correspondant au nombre de caract�res du mot recherch�
	
}

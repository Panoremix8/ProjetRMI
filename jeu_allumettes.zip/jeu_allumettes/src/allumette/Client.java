package allumette;
import java.rmi.*;

public class Client {
	public static void  main(String[] argv) {
		try {
			int port = 8000;
			AllumetteInterface obj = (AllumetteInterface) Naming.lookup("rmi://localhost:" + port + "/allumette");
			
			//tests en dessous
			
			obj.partieEntiere();
			
			//...			
		}
		catch (Exception e) {
			System.out.println("Client exception: " + e);
		}
	}
}

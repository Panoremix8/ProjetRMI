package allumette;
import java.rmi.*;

public interface AllumetteInterface extends Remote{
	
	public int coupJoueur(int nombreAllumette) throws RemoteException;//prend en entree le nb total d allumettes et le renvoie apres le coup du joueur
	
	public int coupOrdi(int nombreAllumette) throws RemoteException;//prend en entree le nb total d allumettes et le renvoie apres le coup de l ordi
	
	public boolean verifFin(int nombreAllumette) throws RemoteException;
	
	public int genererEntierRandom() throws RemoteException;
	
	public void affichageAllumette(int nombreAllumette) throws RemoteException;
	
	public int lireEntier(int nombreAllumette) throws RemoteException;
	
	public boolean verifEntier(int val) throws RemoteException;

	public void partieEntiere() throws RemoteException;
}

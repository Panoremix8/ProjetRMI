package allumette;
import java.rmi.*;
import java.rmi.server.*;
import java.util.Scanner;

@SuppressWarnings("serial")
public class AllumetteImpl extends UnicastRemoteObject implements AllumetteInterface{
	
	public AllumetteImpl() throws RemoteException{
		super();
	}
	
	public void affichageAllumette(int nombreAllumette) throws RemoteException{
		for(int i = 0; i < nombreAllumette; i++) {
			System.out.print("| ");
		}
		System.out.print("\n");
	}
	
	public int genererEntierRandom() throws RemoteException{//genere un entier entre 15 et 30
		return (int) (15 + Math.random() * ( 30 - 15 ));
	}
	
	public int lireEntier(int nombreAllumette) throws RemoteException{
		int val = 0;
		Scanner sc = new Scanner(System.in);
		
		do {
			val = sc.nextInt();
		}
		while(!(verifEntier(val) || val > nombreAllumette));
		return val;
	}
	
	public boolean verifEntier(int val) throws RemoteException{
		boolean res = false;
		
		if(val == 1 || val == 2 || val == 3) {
			res = true;
		}
		
		return res;
	}
	
	public int coupJoueur(int nombreAllumette) throws RemoteException{//gere le coup du joueur
		int val = 0;
		affichageAllumette(nombreAllumette);
		
		System.out.println("Combien d allumettes voulez-vous enlever? (1, 2 ou 3)");
		val = lireEntier(nombreAllumette);
		
		nombreAllumette = nombreAllumette - val;
		System.out.println("vous avez enleve :" + val + " allumettes");
		
		return nombreAllumette;
	}
	
	public int coupOrdi(int nombreAllumette) throws RemoteException{//gere le coup de l ordi
		int val = 0;
		do{
			val = (int) (1 + Math.random() * 3);
		}
		while(val > nombreAllumette);
		System.out.println("l ordi a choisi de prendre " + val + " allumettes");
		nombreAllumette = nombreAllumette - val;
		return nombreAllumette;
	}
	
	public boolean verifFin(int nombreAllumette) throws RemoteException{
		boolean res = false;
		if(nombreAllumette == 0) res = true;
		return res;
	}
	
	public void partieEntiere() throws RemoteException{
		int nombreAllumette = genererEntierRandom();
		boolean gagneJoueur = false;
		System.out.println("oui bienvenue c le jeu des allumettes hihihi");
		
		while(!verifFin(nombreAllumette)) {
			nombreAllumette = coupJoueur(nombreAllumette);
			if(verifFin(nombreAllumette)) {
				gagneJoueur = true;
				break;
			}
			nombreAllumette = coupOrdi(nombreAllumette);
		} 
		if(gagneJoueur) {
			System.out.println("c la fin yes ! bien vu chacal");
		}
		else {
			System.out.println("oh non c perdu :(");
		}
		
	}
}
